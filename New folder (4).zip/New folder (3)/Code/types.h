// CMSC 430 Compiler Theory and Design
// Project 4 Skeleton
// UMGC CITE
// Summer 2023

// This file contains type definitions and the function
// prototypes for the type checking functions

#include <string>

using namespace std;

typedef char* CharPtr;

enum Types { MISMATCH, INT_TYPE, REAL_TYPE, CHAR_TYPE, BOOL_TYPE, LIST_TYPE, NO_TYPE, NONE };

void checkAssignment(Types lValue, Types rValue, string message);
Types checkArithmetic(Types left, Types right);
Types checkRelational(Types left, Types right);
Types checkLogical(Types left, Types right);
void checkIf(Types ifType, Types elseType);
void checkWhen(Types trueType, Types falseType);
void checkSwitch(Types switchType, Types caseType, Types othersType);
Types checkCases(Types left, Types right);
void checkListType(Types elementType, Types listType);
Types checkExpressions(Types left, Types right);
void checkFold(Types operatorType, Types listType);


