// CMSC 430 Compiler Theory and Design
// Project 4 Skeleton
// UMGC CITE
// Summer 2023

// This file contains the bodies of the type checking functions

#include <string>
#include <vector>

using namespace std;

#include "types.h"
#include "listing.h"

void checkAssignment(Types lValue, Types rValue, string message) {
    if (lValue == MISMATCH || rValue == MISMATCH)
        return;
    if (lValue != rValue)
    {
        if (lValue == REAL_TYPE && rValue == INT_TYPE)
        {
            // Widening conversion, acceptable
        }
        else if (lValue == INT_TYPE && rValue == REAL_TYPE)
        {
            appendError(GENERAL_SEMANTIC, "Illegal Narrowing " + message);
        }
        else
        {
            appendError(GENERAL_SEMANTIC, "Type Mismatch on " + message);
        }
    }
}

Types checkArithmetic(Types left, Types right) {
    if (left == MISMATCH || right == MISMATCH)
        return MISMATCH;
    if ((left == INT_TYPE || left == REAL_TYPE) && (right == INT_TYPE || right == REAL_TYPE))
    {
        if (left == REAL_TYPE || right == REAL_TYPE)
            return REAL_TYPE; // Coerce to real
        else
            return INT_TYPE;
    }
    appendError(GENERAL_SEMANTIC, "Arithmetic Operator Requires Numeric Types");
    return MISMATCH;
}

Types checkRelational(Types left, Types right) {
    if (left == MISMATCH || right == MISMATCH)
        return MISMATCH;
    if (left == CHAR_TYPE && right == CHAR_TYPE)
        return BOOL_TYPE;
    if ((left == INT_TYPE || left == REAL_TYPE) && (right == INT_TYPE || right == REAL_TYPE))
        return BOOL_TYPE;
    if ((left == CHAR_TYPE && (right == INT_TYPE || right == REAL_TYPE)) ||
        (right == CHAR_TYPE && (left == INT_TYPE || left == REAL_TYPE)))
    {
        appendError(GENERAL_SEMANTIC, "Character Literals Cannot be Compared to Numeric Expressions");
        return MISMATCH;
    }
    appendError(GENERAL_SEMANTIC, "Type Mismatch in Relational Expression");
    return MISMATCH;
}

Types checkLogical(Types left, Types right) {
    if (left == MISMATCH || right == MISMATCH)
        return MISMATCH;
    if (left == BOOL_TYPE && right == BOOL_TYPE)
        return BOOL_TYPE;
    appendError(GENERAL_SEMANTIC, "Logical Operator Requires Boolean Operands");
    return MISMATCH;
}

void checkIf(Types ifType, Types elseType) {
    if (ifType != elseType)
    {
        appendError(GENERAL_SEMANTIC, "If-Elsif-Else Type Mismatch");
    }
}

void checkWhen(Types trueType, Types falseType) {
    if (trueType != falseType)
    {
        appendError(GENERAL_SEMANTIC, "When Types Mismatch");
    }
}

void checkSwitch(Types switchType, Types caseType, Types othersType) {
    if (switchType != INT_TYPE)
    {
        appendError(GENERAL_SEMANTIC, "Switch Expression Not Integer");
    }
    if (caseType != othersType)
    {
        appendError(GENERAL_SEMANTIC, "Case Types Mismatch");
    }
}

Types checkCases(Types left, Types right) {
    if (left == MISMATCH || right == MISMATCH)
        return MISMATCH;
    if (left == NONE || left == right)
        return right;
    appendError(GENERAL_SEMANTIC, "Case Types Mismatch");
    return MISMATCH;
}

void checkListType(Types elementType, Types listType) {
    if (elementType != listType)
    {
        appendError(GENERAL_SEMANTIC, "List Type Does Not Match Element Types");
    }
}

Types checkExpressions(Types left, Types right) {
    if (left == right)
        return left;
    else
    {
        appendError(GENERAL_SEMANTIC, "List Element Types Do Not Match");
        return MISMATCH;
    }
}

void checkFold(Types operatorType, Types listType) {
    if (listType != INT_TYPE && listType != REAL_TYPE)
    {
        appendError(GENERAL_SEMANTIC, "Fold Requires A Numeric List");
    }
}

